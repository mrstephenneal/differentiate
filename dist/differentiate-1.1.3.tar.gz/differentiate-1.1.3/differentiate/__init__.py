from differentiate.diff import diff


__all__ = ['diff', 'diff.py']
