from differentiate.differentiate import differentiate


__all__ = ['differentiate']
